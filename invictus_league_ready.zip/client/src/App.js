
import React from 'react';
function App() {
  return <div style={{padding:20}}>
    <h1>Invictus League Ready-to-Deploy Version</h1>
    <p>Frontend is working! Backend URL is set via REACT_APP_API_URL environment variable.</p>
  </div>;
}
export default App;
